# -*- coding: utf-8 -*-
""" 
Created on Mon Aug 30 23:26:38 2021

@author: rmorn
"""
#create graphic representation of the files
import matplotlib.pyplot as plt

#Open csv files for the program to work with
import csv

x = []
y = []

# csv file name
gpu = "gpu.csv"
# initializing the titles and rows list
fieldavg = []
row_avg = []

# csv file name
ram = "ram.csv"
# initializing the titles and rows list
fieldavg = []
row_avg = []

# csv file name
cpu = "cpu.csv"
# initializing the titles and rows list
fieldavg = []
row_avg = []

# csv edited file name
gpu_edit = "gpu_edited.csv"
# initializing the titles and rows list
fieldavg = []
row_avg = []

# csv edited file name
ram_edit = "ram_edited.csv"
# initializing the titles and rows list
fieldavg = []
row_avg = []

# csv edited file name
cpu_edit = "cpu_edited.csv"
# initializing the titles and rows list
fieldavg = []
row_avg = []


#Program menu    
def print_menu():
    print (30 * "-" , "MENU" , 30 * "-")
    print ("1. GPU Data")
    print ("2. CPU Data")
    print ("3. RAM Data")
    print ("4. Exit")
    print (67 * "-")
#Displays program menu#
print_menu()


#Function for GPU DATA
def menu1():
    #reading csv file
    with open(gpu, 'r') as csvfile:
    #creating a csv reader object
        readergpu = csv.reader(csvfile, delimiter = ',')
        for row in readergpu:
            x.append(row[0])
            y.append(row[1])

            plt.bar(x, y, color = 'g', width = 0.72, label = "Transistor Count")
            plt.xlabel('Processor')
            plt.ylabel('Transistor Count')
            plt.title('GPU Data Across the Years')
            plt.legend()
            plt.show()

    #reading csv file
    with open(gpu_edit, 'r') as csvfile:
    #creating a csv reader object
        edits = csv.reader(csvfile, delimiter = ',')
        for row in edits:
            x.append(row[0])
            y.append(row[1])

            plt.bar(x, y, color = 'g', width = 0.72, label = "Transistor Count")
            plt.xlabel('Processor')
            plt.ylabel('Transistor Count')
            plt.title('GPU Data Across the Years')
            plt.legend()
            plt.show()


#Function for CPU DATA
def menu2():
    #reading csv file
    with open(cpu, 'r') as csvfile:
    #creating a csv reader object
        readercpu = csv.reader(csvfile)
        for row in readercpu:
            x.append(row[0])
            y.append(row[1])

            plt.bar(x, y, color = 'b', width = 0.72, label = "Transistor Count")
            plt.xlabel('Processor')
            plt.ylabel('Transistor Count')
            plt.title('CPU Data Across the Years')
            plt.legend()
            plt.show()

    #reading csv file
    with open(cpu_edit, 'r') as csvfile:
    #creating a csv reader object
        editcpu = csv.reader(csvfile)
        for row in editcpu:
            x.append(row[0])
            y.append(row[1])

            plt.bar(x, y, color = 'b', width = 0.72, label = "Transistor Count")
            plt.xlabel('Processor')
            plt.ylabel('Transistor Count')
            plt.title('CPU Data Across the Years')
            plt.legend()
            plt.show()


#Function for RAM DATA
def menu3():
    #reading csv file
    with open(ram, 'r') as csvfile:
    #creating a csv reader object
        readerram = csv.reader(csvfile)
        for row in readerram:
            x.append(row[3])
            y.append(row[4])

            plt.bar(x, y, color = 'r', width = 0.72, label = "Transistor Count")
            plt.xlabel('ram type')
            plt.ylabel('Transistor Count')        
            plt.title('RAM Data Across the Years')
            plt.legend()
            plt.show()

    #reading csv file
    with open(ram_edit, 'r') as csvfile:
    #creating a csv reader object
        editram = csv.reader(csvfile)
        for row in editram:
            x.append(row[3])
            y.append(row[4])

            plt.bar(x, y, color = 'r', width = 0.72, label = "Transistor Count")
            plt.xlabel('ram type')
            plt.ylabel('Transistor Count')        
            plt.title('RAM Data Across the Years')
            plt.legend()
            plt.show()


#Ask the user to choose for the program to run
choice = input("Enter your choice [1-4]: ")
"Convert string to int type"
choice = int(choice)

#while loop for program
while(True):
#This choice outputs the GPU data of the csv file of the program
    if choice == 1:
         print ("Menu 1 has been selected")
         menu1()# output the entire file with edited data
         #Ask the user to choose again
         choice = input("Enter your choice [1-4]: ")
         "Convert string to int type"
         choice = int(choice)

#This choice outputs the CPU data of the csv file of the program      
    elif choice == 2:
        menu2() #output the file according the specific data needed
        #Ask the user to choose again
        choice = input("Enter your choice new [1-4]: ")
        "Convert string to int type"
        choice = int(choice)

#This choice outputs the RAM data of the csv file of the program        
    elif choice == 3:
        menu3() #output the file according the specific data needed       
        #Ask the user to choose again
        choice = input("Enter your choice new [1-4]: ")
        "Convert string to int type"
        choice = int(choice)


#This choice ends the program
    elif choice == 4:
        print("Menu 3 has been selected")
        i = False
        "function to exit program"
        print("Thanks for using this program")
        exit()
        
#This choice asks the user to choose again if the number is out of range from 1-3 of the program        
    elif choice > 4:
        print("Invalid number. Try again...")
        #Ask the user to choose again
        choice = input("Enter your choice new [1-4]: ")
        "Convert string to int type"
        choice = int(choice)
