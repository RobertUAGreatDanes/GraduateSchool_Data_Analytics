



# Train test split begin logistical regression
# Splitting the dataset to train and test.
# 75% of data is used for training the model
# 25% of it is used to test the performance of our model.

x_train, x_test, y_train, y_test = (
    train_test_split(train.drop('Call_Flag', axis=1), train['Call_Flag'], test_size=0.25, random_state=0))


# Call the logistical regression from the Sklearn module
logmodel = LogisticRegression()
logmodel.fit(x_train, y_train)
predictions = logmodel.predict(x_test)

# Evaluation the trained module to see about accuracy
print(classification_report(y_test, predictions))
print("Accuracy:", metrics.accuracy_score(y_test, predictions))


# Train test split begin logistical regression
# Splitting the dataset to train and test.
# 75% of data is used for training the model
# 25% of it is used to test the performance of our model.

x_train, x_test, y_train, y_test = (
    train_test_split(train.drop('Call_Flag', axis=1), train['Call_Flag'], test_size=0.25, random_state=0))


# Call the logistical regression from the Sklearn module
logmodel = LogisticRegression()
logmodel.fit(x_train, y_train)
predictions = logmodel.predict(x_test)

# Evaluation the trained module to see about accuracy
print(classification_report(y_test, predictions))
print("Accuracy:", metrics.accuracy_score(y_test, predictions))
