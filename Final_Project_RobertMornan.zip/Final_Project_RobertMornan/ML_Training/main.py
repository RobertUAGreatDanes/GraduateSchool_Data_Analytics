# Robert Mornan
# 001336565
# INF 528
# Analysis, Visualization, and Prediction in Analytics

import pandas as pd
import matplotlib.pyplot as plt
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.preprocessing import StandardScaler
import seaborn as sns

# Set style for the gird that will be shown using matplotlib.pyplot
sns.set(style="white")
sns.set(style="whitegrid", color_codes=True)

# input the file that will be used to train the model for machine learning
train = pd.read_csv('data.csv', header=0)

sns.countplot(x='CustomerSegment', hue='MART_STATUS', data=train, palette='RdBu_r')
# output countplot matplotlib.pyplot
plt.show()
sns.countplot(x='DATE_FOR', hue='GENDER', data=train, palette='RdBu_r')
# output countplot matplotlib.pyplot
plt.show()
sns.countplot(x='LOGINS', hue='POLICYPURCHASECHANNEL', data=train, palette='RdBu_r')
# output countplot with matplotlib.pyplot
plt.show()

# correlation heat-plot
# plotting correlation heatmap
dataplot = sns.heatmap(train.corr())
# displaying heatmap
plt.show()

# prints data that will be plotted
# columns shown here are selected by corr() since
# they are ideal for the plot
print(train.corr())
# plotting correlation heatmap
dataplot = sns.heatmap(train.corr(), cmap="YlGnBu", annot=True)
# displaying heatmap
plt.show()

# Output update table without the changes that we made such as dropping the columns
print(train.head(10))


# drop tables
train.drop(['DATE_FOR', 'RTD_ST_CD', 'CustomerSegment', 'GENDER'], axis=1, inplace=True)
train.dropna(inplace=True)
# Converting our categorical values to dummy variables using pandas
# Utilize pandas module to alter the tables to suit our logistical regression goals

train.drop(['CHANNEL1_6M', 'CHANNEL2_6M', 'CHANNEL3_6M', 'CHANNEL4_6M', 'CHANNEL5_6M', 'CHANNEL1_3M', 'CHANNEL2_3M',
            'CHANNEL3_3M', 'CHANNEL4_3M', 'CHANNEL5_3M', 'MART_STATUS', 'LOGINS'], axis=1, inplace=True)

# Output update table with the changes that we made such as dropping the columns
print(train.head(10))

# Train test split begin logistical regression
# Splitting the dataset to train and test.
# 75% of data is used for training the model
# 25% of it is used to test the performance of our model.

# labels and features.Labels are the data which
# we want to predict and features are the
# data which are used to predict labels.
x_train, x_test, y_train, y_test = (
    train_test_split(train.drop('Call_Flag', axis=1), train['POLICYPURCHASECHANNEL'], test_size=0.20, random_state=0))

# Scale the data since the ages vary between all passengers
sc_x = StandardScaler()
x_train = sc_x.fit_transform(x_train)
x_test = sc_x.transform(x_test)
print(x_train[0:10, :])
print("\nX_train:\n")
# print(x_train.head())
print(x_train.shape)
print("\nX_test:\n")
# print(x_test.head())
print(x_test.shape)


# Call the logistical regression from the Sklearn module
logmodel = LogisticRegression()
logmodel.fit(x_train, y_train)
predictions = logmodel.predict(x_test)

# Evaluation the trained module to see about accuracy
print(classification_report(y_test, predictions))
print("Accuracy:", metrics.accuracy_score(y_test, predictions))
