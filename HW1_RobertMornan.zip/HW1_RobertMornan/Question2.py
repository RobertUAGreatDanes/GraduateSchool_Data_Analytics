#Robert Mornan
# 001336565
#INF 428/528: Analysis, Visualization, and Prediction in Analytics
# Section: INF 528

# function to remove duplicate elements
def Remove(duplicate):
    no_dubplicates = []
#for checks for the duplicates in the lists
    for num in duplicate:
        if num not in no_dubplicates:
#append or update the list as each dublpicate is removed
            no_dubplicates.append(num)
# returns the listen without the duplicates to be printed
    return no_dubplicates

# Test code for the function
duplicate = [2, 5, 5, 16, 21, 4, 10, 18, 3, 7, 18,  20, 5, 2, 20, 4, 21, 16, 18, 3, 7, 2]
print(Remove(duplicate))
exit()

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print('hello')