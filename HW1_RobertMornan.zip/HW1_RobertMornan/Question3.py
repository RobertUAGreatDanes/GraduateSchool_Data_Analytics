#Robert Mornan
# 001336565
#INF 428/528: Analysis, Visualization, and Prediction in Analytics
# Section: INF 528
#creates a function that replicates the fibonacci series
def fib_series():
#ask users for their input and convert them to numbers
    num = int(input("Please enter how many numbers would you like in your Fibonacci sequence: "))
#the first number to start the series
    i = 1
#if the user enters the number zero the list returns empty
    if num == 0:
        fib = []
#if the user enters a number lower than zero the list returns empty
    elif num < 0:
        fib = []
    elif num == 1:
        fib = [1]
    elif num == 2:
        fib = [1,1]
    elif num > 2:
        fib = [1,1]
#this while loop manipulates the list according to user input
        while i < (num - 1):
            fib.append(fib[i] + fib[i-1])
            i += 1
#returns the lists with all the numbers based on user input
    return fib
#prints out the completed function
print (fib_series())
exit()
# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print("Thanks for using the program")
    exit()