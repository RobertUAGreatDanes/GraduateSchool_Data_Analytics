# Robert Mornan
# 001336565
# INF 428/528: Analysis, Visualization, and Prediction in Analytics
# Section: INF 528
# imports the random packages, so we can get random ints in python
from random import randint

# creating the board
board = []
# placeholder for user entries
turn = 0
for x in range(5):
    board.append(["O"] * 5)


# function for print the board 5X5 board
def print_board(board):
    for row in board:
        print(" ".join(row))


# start the game and print the board
print("Game Start!")
print("Here is my 5x5 Game Board.")
print_board(board)


# function for placing the ships on the board randomly
def random_row(board):
    return randint(0, len(board) - 1)


def random_col(board):
    return randint(0, len(board[0]) - 1)


# the random numbers for row and column are assign to a ship variable
ship_row = random_row(board)
ship_col = random_col(board)
print("The target ship is located at:", "(", ship_row, ",", ship_col, ")")

# ask the user for a guess limit turns to 4 attempts
for turn in range(4):
    guess_row = input("Guess Row:")
    guess_col = input("Guess Col:")

    # convert string to an int for comparison
    converted_row = int(guess_row)
    converted_col = int(guess_col)

    # if statement for the user's input being right, causes the game to end
    if converted_row == ship_row and converted_col == ship_col:
        print("Congratulations! You sunk my battleship!")
        break
    else:
        # if the guess is out of the board remind the user their entry is out of bounds
        if (converted_row < 0 or converted_row > 4) or (converted_col < 0 or converted_col > 4):
            print("Oops, that's not even in the ocean.")

        # if the guess was already made remind the user their entry was already chosen
        elif board[converted_row][converted_col] == "X":
            print("You already guessed that spot. Try Again!.")

        # if the guess is wrong, mark the point with an X and start again
        else:
            print("You missed the battleship! Try Again")
            board[converted_row][converted_col] = "X"
            print_board(board)

        # Print turn and board again here
        print("Turn " + str(turn + 1) + " out of 4.")
        # print_board(board)

# if the user have made 4 tries, it's game over
if turn >= 3:
    print("Game Over")

# Press the green button in the gutter to run the script.
if __name__ == '__main__':
    print("Thanks for playing. Goodbye!")
exit()
