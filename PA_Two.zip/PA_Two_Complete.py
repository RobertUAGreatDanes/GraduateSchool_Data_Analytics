# -*- coding: utf-8 -*-
"""
Created on Mon Aug 30 23:26:38 2021

@author: rmorn
"""

#Open csv files for the program to work with
import csv

# csv file name
tuition_edit = "us_avg_tuition_edited.csv"
# initializing the titles and rows list
fieldavg = []
row_avg = []



#Program menu    
def print_menu():
    print (30 * "-" , "MENU" , 30 * "-")
    print ("1. Whole US Data")
    print ("2. Data for a specified US State")
    print ("3. Exit")
    print (67 * "-")
#Displays program menu#
print_menu()


#This function when called will print out the edited csv file of the entire state
def menu1():
    #reading csv file
    with open(tuition_edit, 'r') as csvfile:
    #creating a csv reader object
        reader = csv.reader(csvfile)
    # extracting field names through first row
        fieldavg = next(csvfile)
    # extracting each data row one by one
        for row in reader:
            row_avg.append(row)
    #get total number of rows
    print("Total no. of rows: %d"%(reader.line_num))
    #output the csv file if the user input is found 
    print(row_avg)

#This function when called will print out the edited csv file by the state the user inputs 
def menu2():
   #get the specific state from user input
    stateinput = input('Enter the state name you which to print the data from? e.g: New York or Alabama: ')
    #check if users input is in csv file
    #reading csv file
    with open(tuition_edit, 'r') as csvfile:
        csvreader = csv.reader(csvfile)
        # extracting field names through first row
        fieldavg = next(csvreader)
        print(fieldavg)
        # extracting each data row one by one
        for row in csvreader:
            row_avg.append(row)
            if (row[0] == stateinput):
                #output the csv file if the user input is found 
                print(stateinput) 
    
    
#Ask the user to choose again
choice = input("Enter your choice [1-3]: ")
"Convert string to int type"
choice = int(choice)

#while loop for program
while(True):
#This choice outputs the entire ediited csv file of the program
    if choice == 1:
         print ("Menu 1 has been selected")
         menu1()# output the entire file with edited data
         #Ask the user to choose again
         choice = input("Enter your choice [1-3]: ")
         "Convert string to int type"
         choice = int(choice)
         
#This choice outputs the data from the specific state entered the program        
    elif choice == 2:
        menu2() #output the file according the specific data needed
                
        #Ask the user to choose again
        choice = input("Enter your choice new [1-3]: ")
        "Convert string to int type"
        choice = int(choice)

#This choice ends the program
    elif choice == 3:
        print("Menu 3 has been selected")
        i = False
        "function to exit program"
        print("Thanks for using this program")
        exit()
        
#This choice asks the user to choose again if the number is out of range from 1-3 of the program        
    elif choice > 3:
        print("Invalid number. Try again...")
        #Ask the user to choose again
        choice = input("Enter your choice new [1-3]: ")
        "Convert string to int type"
        choice = int(choice)
