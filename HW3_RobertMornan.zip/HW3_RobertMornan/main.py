#Robert Mornan
#001336565
#INF 528
#Analysis, Visualizaton, and Predicition in Analytics

import pandas as pd
import matplotlib.pyplot as plt
from sklearn import metrics
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report
from sklearn.preprocessing import StandardScaler
import seaborn as sns

# Set style for the gird that will be shown using matplotlib.pyplot
sns.set(style="white")
sns.set(style="whitegrid", color_codes=True)

# input the file that will be used to train the logistical regression model
train = pd.read_csv('titanic/train.csv', header=0)

# 'Output the head of the table before any changes have been made'
print(train.head())

sns.countplot(x='Survived', data=train, palette='RdBu_r')
# output countplot for who died and who survived with matplotlib.pyplot
plt.show()
sns.countplot(x='Survived', hue='Sex', data=train, palette='RdBu_r')
# output countplot for who died and who survived in terms of gender male or female with matplotlib.pyplot
plt.show()

plt.figure(figsize=(12, 7))
sns.boxplot(x='Pclass', y='Age', data=train, palette='winter')
# output boxplot with matplotlib.pyplot
plt.show()


# Create a function to impute the age on the Pclass column that is found in the table
def impute_age(cols):
    Age = cols[0]
    Pclass = cols[1]

    if pd.isnull(Age):
        if Pclass == 1:
            return 37
        elif Pclass == 2:
            return 29
        else:
            return 24
    else:
        return Age


# Call the function impute age
train['Age'] = train[['Age', 'Pclass']].apply(impute_age, axis=1)
sns.heatmap(train.isnull(), yticklabels=False, cbar=False, cmap='viridis')
# output heatmap with matplotlib.pyplot
plt.show()
train.drop('Cabin', axis=1, inplace=True)
train.dropna(inplace=True)
print(train.head())

# View the categorical values of the table
train.info()
# Converting our categorical values to dummy variables using pandas
# Utilize pandas module to alter the tables to suit our logistical regression goals
sex = pd.get_dummies(train['Sex'], drop_first=True)
embark = pd.get_dummies(train['Embarked'], drop_first=True)
train.drop(['Sex', 'Embarked', 'Name', 'Ticket'], axis=1, inplace=True)
train = pd.concat([train, sex, embark], axis=1)
# Output update table with the changes that we made such as dropping the columns
print(train.head())

# Train test split begin logistical regression
# Splitting the dataset to train and test.
# 80% of data is used for training the model
# 20% of it is used to test the performance of our model.

x_train, x_test, y_train, y_test = (
    train_test_split(train.drop('Survived', axis=1), train['Survived'], test_size=0.20, random_state=0))

# Scale the data since the ages vary between all passengers
sc_x = StandardScaler()
x_train = sc_x.fit_transform(x_train)
x_test = sc_x.transform(x_test)
print(x_train[0:10, :])

# Call the logistical regression from the Sklearn module
logmodel = LogisticRegression()
logmodel.fit(x_train, y_train)
predictions = logmodel.predict(x_test)

# Evaluation the trained module to see about accuracy
print(classification_report(y_test, predictions))
print("Accuracy:", metrics.accuracy_score(y_test, predictions))
